var im=document.getElementById("im");
var w=document.getElementById("w");
var z=document.getElementById("z");
var y=document.getElementById("y");
var zz=document.getElementById("zz");

z.onmouseenter=function(){
    im.style.color="#fff";
    w.style.color="#fff";
   im.style.transition = "0.3s";  
  w.style.transition = "0.3s";  
}
w.onmouseenter=function(){
    im.style.color="#fff";
    w.style.color="#fff";
    im.style.transition = "0.3s";  
    w.style.transition = "0.3s";  
}
z.onmouseleave=function(){
    im.style.color="#cdcac8";
    w.style.color="#cdcac8";
    im.style.transition = "0.3s";  
    w.style.transition = "0.3s";  
}

var imm=document.getElementById("imm");
var ww=document.getElementById("ww");
y.onmouseenter=function(){
    imm.style.color="#fff";
    ww.style.color="#fff";
    imm.style.transition = "0.3s";  
    ww.style.transition = "0.3s";  
}
ww.onmouseenter=function(){
    imm.style.color="#fff";
    ww.style.color="#fff";
    imm.style.transition = "0.3s";  
    ww.style.transition = "0.3s";  
}
y.onmouseleave=function(){
    imm.style.color="#cdcac8";
    ww.style.color="#cdcac8";
    imm.style.transition = "0.3s";  
    ww.style.transition = "0.3s";  
}

var immm=document.getElementById("immm");
var www=document.getElementById("www");
zz.onmouseenter=function(){
    immm.style.color="#fff";
    www.style.color="#fff";
    immm.style.transition = "0.3s";  
    www.style.transition = "0.3s";  
}
www.onmouseenter=function(){
    immm.style.color="#fff";
    www.style.color="#fff";
    immm.style.transition = "0.3s";  
    www.style.transition = "0.3s";  
}
zz.onmouseleave=function(){
    immm.style.color="#cdcac8";
    www.style.color="#cdcac8";
    immm.style.transition = "0.3s";  
    www.style.transition = "0.3s";  
}

var immmm=document.getElementById("immmm");
var wwww=document.getElementById("wwww");
var yyy=document.getElementById("yyy");   
yyy.onmouseenter=function(){
    immmm.style.color="#fff";
    wwww.style.color="#fff";
    immmm.style.transition = "0.3s";  
    wwww.style.transition = "0.3s";  
}
wwww.onmouseenter=function(){
    immmm.style.color="#fff";
    wwww.style.color="#fff";
    immmm.style.transition = "0.3s";  
    wwww.style.transition = "0.3s";  
}
yyy.onmouseleave=function(){
    immmm.style.color="#cdcac8";
    wwww.style.color="#cdcac8";
    immmm.style.transition = "0.3s";  
    wwww.style.transition = "0.3s";  
}

var immmmm=document.getElementById("immmmm");
var wwwww=document.getElementById("wwwww");
var zzz=document.getElementById("zzz");  
zzz.onmouseenter=function(){
    immmmm.style.color="#fff";
    wwwww.style.color="#fff";
    immmmm.style.transition = "0.3s";  
    wwwww.style.transition = "0.3s";  
}
wwwww.onmouseenter=function(){
    immmmm.style.color="#fff";
    wwwww.style.color="#fff";
    immmmm.style.transition = "0.3s";  
    wwwww.style.transition = "0.3s"; 
}
zzz.onmouseleave=function(){
    immmmm.style.color="#cdcac8";
    wwwww.style.color="#cdcac8";
    immmmm.style.transition = "0.3s";  
    wwwww.style.transition = "0.3s"; 
}

var imn=document.getElementById("imn");
var wn=document.getElementById("wn");
var yyyy=document.getElementById("yyyy");
yyyy.onmouseenter=function(){
    imn.style.color="#fff";
    wn.style.color="#fff";
    imn.style.transition = "0.3s";  
    wn.style.transition = "0.3s"; 
}
wn.onmouseenter=function(){
    imn.style.color="#fff";
    wn.style.color="#fff";
    imn.style.transition = "0.3s";  
    wn.style.transition = "0.3s"; 
}
yyyy.onmouseleave=function(){
    imn.style.color="#cdcac8";
    wn.style.color="#cdcac8";
    imn.style.transition = "0.3s";  
    wn.style.transition = "0.3s"; 
}