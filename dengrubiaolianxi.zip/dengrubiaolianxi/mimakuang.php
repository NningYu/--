<?php
    $username= $_POST['username'];
    $password= $_POST['password'];
    $repasswd= $_POST['repasswd'];

//验证
if($password !== $repasswd){
    echo '{"code":-1, "msg":"两次密码不一致"}';
    exit();
}

$mysqli =new mysqli('localhost','root','root','date');

if($mysqli->connect_errno){
    echo '{"cod": -2,"msg":"网络连接失败"}';
    exit(); 
}

$result = $mysqli->query("select id from users where username='$username';");

if($result->num_rows > 0){
   echo '{"code":-3,"msg":"用户名已注册" }';
}else{
    $result = $mysqli->query("insert into users(username, password) values('$username', '$password');");

    if($result == TRUE){
        echo '{"code":200,"msg":"注册成功"}';
    }else{
        echo '{"code":-2,"msg":"网络连接失败"}';
    }
}
$mysqli->close();
?>